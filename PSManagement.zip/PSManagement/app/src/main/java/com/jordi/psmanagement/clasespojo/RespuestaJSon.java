package com.jordi.psmanagement.clasespojo;

public class RespuestaJSon {
    public int respuesta;
    public String metodo;
    public String tabla;
    public String mensaje;
    public String sqlQuery;
    public String sqlError;

    public RespuestaJSon() {
    }

    public int getRespuesta() {
        return respuesta;
    }

    public void setRespuesta(int respuesta) {
        this.respuesta = respuesta;
    }

    public String getMetodo() {
        return metodo;
    }

    public void setMetodo(String metodo) {
        this.metodo = metodo;
    }

    public String getTabla() {
        return tabla;
    }

    public void setTabla(String tabla) {
        this.tabla = tabla;
    }

    public String getMensaje() {
        return mensaje;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }

    public String getSqlQuery() {
        return sqlQuery;
    }

    public void setSqlQuery(String sqlQuery) {
        this.sqlQuery = sqlQuery;
    }

    public String getSqlError() {
        return sqlError;
    }

    public void setSqlError(String sqlError) {
        this.sqlError = sqlError;
    }

    @Override
    public String toString() {
        return "RespuestaJSon{" +
                "respuesta=" + respuesta +
                ", metodo='" + metodo + '\'' +
                ", tabla='" + tabla + '\'' +
                ", mensaje='" + mensaje + '\'' +
                ", sqlQuery='" + sqlQuery + '\'' +
                ", sqlError='" + sqlError + '\'' +
                '}';
    }
}

