package com.jordi.psmanagement.fragments;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.jordi.psmanagement.R;
import com.jordi.psmanagement.activities.Aplicacion;
import com.jordi.psmanagement.activities.MainActivity;
import com.jordi.psmanagement.adapter.Adaptador;
import com.jordi.psmanagement.clasespojo.Articulo;
import com.jordi.psmanagement.interfaces.OnSelectedItemListener;
import com.jordi.psmanagement.interfaces.ProveedorServicios;

import java.util.ArrayList;
import java.util.Objects;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class FragmentArticulos extends Fragment {
    private RecyclerView recyclerView;
    private Adaptador adaptador;
    private SwipeRefreshLayout swipeRefreshLayout;
    private ArrayList<Articulo> datosArticulos;
    private OnSelectedItemListener listener;
    private boolean refrescando;

    public FragmentArticulos() {
        this.datosArticulos = Aplicacion.datosArticulos;
        refrescando = false;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.recycler_layout, container, false);

        recyclerView = rootView.findViewById(R.id.recycler);
        adaptador = new Adaptador(datosArticulos, getActivity());

        recyclerView.setAdapter(adaptador);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false));

        adaptador.onClickListener(v -> listener.onSelectedItem(datosArticulos.get(recyclerView.getChildAdapterPosition(v)), 1, 0));

        if (datosArticulos != null && datosArticulos.isEmpty()) {
            cargarArticulos();
        }

        swipeRefreshLayout = rootView.findViewById(R.id.swipeRefreshLayout);

        swipeRefreshLayout.setColorSchemeResources(R.color.colorPrimary);
        swipeRefreshLayout.setProgressBackgroundColorSchemeResource(R.color.colorFuente);

        swipeRefreshLayout.setOnRefreshListener(() -> {
            refrescando = true;
            datosArticulos.clear();
            adaptador.notifyDataSetChanged();
            cargarArticulos();
        });

        return rootView;
    }


    private void cargarArticulos() {
        ProveedorServicios proveedorServicios = MainActivity.crearRetrofit();

        Call<ArrayList<Articulo>> responseCall = proveedorServicios.getArticulos(1);

        //Llamada asíncrona gestionada por Retrofit y para ahorrar hilos
        responseCall.enqueue(new Callback<ArrayList<Articulo>>() {
            @Override
            public void onResponse(Call<ArrayList<Articulo>> call, Response<ArrayList<Articulo>> response) {
                ArrayList<Articulo> articulosResponse = response.body();

                if (articulosResponse != null) {
                    datosArticulos.addAll(articulosResponse);

                    if (refrescando) {
                        refrescando = false;
                        swipeRefreshLayout.setRefreshing(false);
                    }

                    adaptador.notifyDataSetChanged();
                } else
                    Toast.makeText(getActivity(), "Aún no hay artículos:" + response.message(), Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onFailure(Call<ArrayList<Articulo>> call, Throwable t) {
                Log.e("Error", t.toString());
                Toast.makeText(getActivity(), "Error:" + t.toString(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        try {
            listener = (OnSelectedItemListener) context;
        } catch (ClassCastException e) {
            e.printStackTrace();
        }
    }
}
