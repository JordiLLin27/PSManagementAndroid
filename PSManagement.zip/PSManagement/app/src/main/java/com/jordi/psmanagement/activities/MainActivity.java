package com.jordi.psmanagement.activities;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;

import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.jordi.psmanagement.R;
import com.jordi.psmanagement.interfaces.ProveedorServicios;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {

    public static String URL_APIRESTINSTI = "http://pdam04b.iesdoctorbalmis.info/bdtiendam/";

    int contador;
    ImageView imgInicio;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imgInicio = findViewById(R.id.imgButtonInicio);
        imgInicio.setOnClickListener(v -> iniciarApp());
        contador = 0;
    }

    //Inicia la actividad principal
    private void iniciarApp() {
        Intent intent = new Intent(MainActivity.this, Aplicacion.class);
        startActivity(intent);
    }

    @Override
    public void onBackPressed() {
        //Se controlan las pulsaciones del botón atrás y se confirma la salida de la aplicación en general.
        if (contador == 0) {
            Toast.makeText(getApplicationContext(), "Presione de nuevo para salir", Toast.LENGTH_LONG).show();
            contador++;
        } else {
            System.exit(0);
            super.onBackPressed();
        }

        //Temporizado para la segunda pulsación del botón atrás
        new CountDownTimer(1000, 500) {

            @Override
            public void onTick(long millisUntilFinished) {
            }

            @Override
            public void onFinish() {
                contador = 0;
            }

        }.start();

    }

    //Provee los servicios de consulta a la api rest
    public static ProveedorServicios crearRetrofit() {

        String url = MainActivity.URL_APIRESTINSTI;
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(url)
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        return retrofit.create(ProveedorServicios.class);
    }
}
