package com.jordi.psmanagement.clasespojo;

public class TallasTextiles {

    String CodArticulo;
    int XXS, XS, S, M, L, XL, XXL, TotalCantidadArticulo;

    public TallasTextiles() {
    }

    public TallasTextiles(String codArticulo, int XXS, int XS, int s, int m, int l, int XL, int XXL, int totalCantidadArticulo) {
        CodArticulo = codArticulo;
        this.XXS = XXS;
        this.XS = XS;
        S = s;
        M = m;
        L = l;
        this.XL = XL;
        this.XXL = XXL;
        TotalCantidadArticulo = totalCantidadArticulo;
    }

    public String getCodArticulo() {
        return CodArticulo;
    }

    public void setCodArticulo(String codArticulo) {
        CodArticulo = codArticulo;
    }

    public int getXXS() {
        return XXS;
    }

    public void setXXS(int XXS) {
        this.XXS = XXS;
    }

    public int getXS() {
        return XS;
    }

    public void setXS(int XS) {
        this.XS = XS;
    }

    public int getS() {
        return S;
    }

    public void setS(int s) {
        S = s;
    }

    public int getM() {
        return M;
    }

    public void setM(int m) {
        M = m;
    }

    public int getL() {
        return L;
    }

    public void setL(int l) {
        L = l;
    }

    public int getXL() {
        return XL;
    }

    public void setXL(int XL) {
        this.XL = XL;
    }

    public int getXXL() {
        return XXL;
    }

    public void setXXL(int XXL) {
        this.XXL = XXL;
    }

    public int getTotalCantidadArticulo() {
        return TotalCantidadArticulo;
    }

    public void setTotalCantidadArticulo(int totalCantidadArticulo) {
        TotalCantidadArticulo = totalCantidadArticulo;
    }

    @Override
    public String toString() {
        return "TallasTextiles{" +
                "CodArticulo='" + CodArticulo + '\'' +
                ", XXS=" + XXS +
                ", XS=" + XS +
                ", S=" + S +
                ", M=" + M +
                ", L=" + L +
                ", XL=" + XL +
                ", XXL=" + XXL +
                ", TotalCantidadArticulo=" + TotalCantidadArticulo +
                '}';
    }
}
