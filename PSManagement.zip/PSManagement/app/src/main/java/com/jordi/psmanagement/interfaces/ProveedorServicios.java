package com.jordi.psmanagement.interfaces;

import com.jordi.psmanagement.clasespojo.Articulo;
import com.jordi.psmanagement.clasespojo.Categoria;
import com.jordi.psmanagement.clasespojo.Color;
import com.jordi.psmanagement.clasespojo.Inventario;
import com.jordi.psmanagement.clasespojo.NumerosCalzado;
import com.jordi.psmanagement.clasespojo.TallasTextiles;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Headers;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface ProveedorServicios {

    @GET("articulos/StockDisponible/")
    @Headers({"Accept: application/json", "Content-Type: application/json"})
    Call<ArrayList<Articulo>> getArticulos(@Query("desde") int valor); //@Query("search") String search);

    @GET("colores/{idColor}")
    @Headers({"Accept: application/json", "Content-Type: application/json"})
    Call<ArrayList<Color>> getColor(@Path("idColor") int idColor); //@Query("search") String search);

    @GET("categorias/{idCategoria}")
    @Headers({"Accept: application/json", "Content-Type: application/json"})
    Call<ArrayList<Categoria>> getCategoria(@Path("idCategoria") int idCategoria); //@Query("search") String search);

    @GET("inventarios/{idInventarios}")
    @Headers({"Accept: application/json", "Content-Type: application/json"})
    Call<ArrayList<Inventario>> getInventario(@Path("idInventarios") int idColor); //@Query("search") String search);

    @GET("tallastextiles/{codArticulo}")
    @Headers({"Accept: application/json", "Content-Type: application/json"})
    Call<ArrayList<TallasTextiles>> getTallasTextiles(@Path("codArticulo") String codArticulo); //@Query("search") String search);

    @GET("numeroscalzado/{codArticulo}")
    @Headers({"Accept: application/json", "Content-Type: application/json"})
    Call<ArrayList<NumerosCalzado>> getNumerosCalzado(@Path("codArticulo") String codArticulo); //@Query("search") String search);
}
