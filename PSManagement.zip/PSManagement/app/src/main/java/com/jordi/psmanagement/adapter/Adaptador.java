package com.jordi.psmanagement.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.jordi.psmanagement.R;
import com.jordi.psmanagement.clasespojo.Articulo;
import com.squareup.picasso.Picasso;


import java.util.ArrayList;

import static java.lang.String.format;


public class Adaptador extends RecyclerView.Adapter implements View.OnClickListener {

    private ArrayList<Articulo> datos;
    private View.OnClickListener listenerClick;
    private Context context;

    public Adaptador(ArrayList<Articulo> datos, Context context) {
        this.datos = datos;
        this.context = context;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.linear_recycler, parent, false);

        v.setOnClickListener(this);

        Holder holder = new Holder(v, context);


        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        ((Holder) holder).bindHolder(datos.get(position));
    }

    @Override
    public int getItemCount() {
        return datos.size();
    }

    public void onClickListener(View.OnClickListener clickListener) {
        this.listenerClick = clickListener;
    }

    @Override
    public void onClick(View v) {
        if (this.listenerClick != null) {
            listenerClick.onClick(v);
        }
    }
}

class Holder extends RecyclerView.ViewHolder {

    private TextView nombreArticulo, codigoArticulo, precioArticulo;
    private ImageView imagenArt;
    private Context context;

    Articulo articulo;

    Holder(@NonNull View itemView, Context context) {
        super(itemView);
        nombreArticulo = itemView.findViewById(R.id.tvNombreArticulo);
        codigoArticulo = itemView.findViewById(R.id.tvCodigoArticulo);
        imagenArt = itemView.findViewById(R.id.imgViewImagenArticulo);
        precioArticulo = itemView.findViewById(R.id.tvPrecioArticulo);
        this.context = context;

    }

    @SuppressLint("DefaultLocale")
    void bindHolder(Articulo articulo) {
        nombreArticulo.setText(articulo.getNombre());
        codigoArticulo.setText(articulo.getCodArticulo());
        precioArticulo.setText(format("%.2f€", articulo.getPrecioUnitario()));

        if (!articulo.getUrlImagen().contains("Assets")) {
            //Descarga la imagen a través de la url y la asigna al ImageView
            Picasso.get().load(articulo.getUrlImagen()).into(imagenArt);

        } else {
            //Si el artículo tiene la ruta de la imagen por defecto de la aplicación de escritorio se le asigna la imagen por defecto.
            imagenArt.setImageResource(R.drawable.no_image_available);
        }

        this.articulo = articulo;
    }
}