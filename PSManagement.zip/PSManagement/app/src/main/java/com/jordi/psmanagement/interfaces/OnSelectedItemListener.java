package com.jordi.psmanagement.interfaces;

import com.jordi.psmanagement.clasespojo.Articulo;

public interface OnSelectedItemListener {
    void onSelectedItem(Articulo articulo, int codigo, int stock);
}
