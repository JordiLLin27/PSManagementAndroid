package com.jordi.psmanagement.clasespojo;

public class Color {
    int IdColor;
    String Color;

    public Color() {
    }

    public Color(int idColor, String color) {
        this.IdColor = idColor;
        this.Color = color;
    }

    public int getIdColor() {
        return IdColor;
    }

    public void setIdColor(int idColor) {
        this.IdColor = idColor;
    }

    public String getColor() {
        return Color;
    }

    public void setColor(String color) {
        this.Color = color;
    }

    @Override
    public String toString() {
        return "Colores{" +
                "idColor=" + IdColor +
                ", color='" + Color + '\'' +
                '}';
    }
}
