package com.jordi.psmanagement.clasespojo;

import android.graphics.Bitmap;

import java.io.Serializable;

public class Articulo implements Serializable {

    String CodArticulo;
    int Inventario;
    int Categoria;
    int Color;
    String Nombre;
    float PrecioUnitario;
    int StockMinimo;
    boolean StockDisponible;
    String UrlImagen;
    Bitmap imagenItemBitmap;

    public Articulo() {
    }

    public Articulo(String codArticulo, int inventario, int categoria, int color, String nombre, float precioUnitario, int stockMinimo, boolean stockDisponible, String urlImagen) {
        this.CodArticulo = codArticulo;
        this.Inventario = inventario;
        this.Categoria = categoria;
        this.Color = color;
        this.Nombre = nombre;
        this.PrecioUnitario = precioUnitario;
        this.StockMinimo = stockMinimo;
        this.StockDisponible = stockDisponible;
        this.UrlImagen = urlImagen;
    }

    public String getCodArticulo() {
        return CodArticulo;
    }

    public void setCodArticulo(String codArticulo) {
        this.CodArticulo = codArticulo;
    }

    public int getInventario() {
        return Inventario;
    }

    public void setInventario(int inventario) {
        this.Inventario = inventario;
    }

    public int getCategoria() {
        return Categoria;
    }

    public void setCategoria(int categoria) {
        this.Categoria = categoria;
    }

    public int getColor() {
        return Color;
    }

    public void setColor(int color) {
        this.Color = color;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String nombre) {
        this.Nombre = nombre;
    }

    public float getPrecioUnitario() {
        return PrecioUnitario;
    }

    public void setPrecioUnitario(float precioUnitario) {
        this.PrecioUnitario = precioUnitario;
    }

    public int getStockMinimo() {
        return StockMinimo;
    }

    public void setStockMinimo(int stockMinimo) {
        this.StockMinimo = stockMinimo;
    }

    public boolean isStockDisponible() {
        return StockDisponible;
    }

    public void setStockDisponible(boolean stockDisponible) {
        this.StockDisponible = stockDisponible;
    }

    public String getUrlImagen() {
        return UrlImagen;
    }

    public void setUrlImagen(String urlImagen) {
        this.UrlImagen = urlImagen;
    }

    public Bitmap getImagenItemBitmap() {
        return imagenItemBitmap;
    }

    public void setImagenItemBitmap(Bitmap imagenItemBitmap) {
        this.imagenItemBitmap = imagenItemBitmap;
    }

    @Override
    public String toString() {
        return "Item{" +
                "codArticulo='" + CodArticulo + '\'' +
                ", inventario=" + Inventario +
                ", categoria=" + Categoria +
                ", color=" + Color +
                ", nombre='" + Nombre + '\'' +
                ", precioUnitario=" + PrecioUnitario +
                ", stockMinimo=" + StockMinimo +
                ", stockDisponible=" + StockDisponible +
                ", urlImagen='" + UrlImagen + '\'' +
                '}';
    }
}
