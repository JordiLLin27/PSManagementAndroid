package com.jordi.psmanagement.activities;

import android.content.res.Configuration;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.jordi.psmanagement.R;
import com.jordi.psmanagement.clasespojo.Articulo;
import com.jordi.psmanagement.fragments.FragmentArticulos;
import com.jordi.psmanagement.fragments.FragmentDetallesArticulo;
import com.jordi.psmanagement.fragments.FragmentStockArticulo;
import com.jordi.psmanagement.interfaces.OnSelectedItemListener;
import com.jordi.psmanagement.interfaces.ProveedorServicios;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Aplicacion extends AppCompatActivity implements OnSelectedItemListener, SearchView.OnQueryTextListener {

    public static ArrayList<Articulo> datosArticulos;
    int contador;

    @Override
    protected void onStart() {
        super.onStart();
    }

    @Override
    protected void onStop() {
        super.onStop();
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.aplicacion);
        contador = 0;
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        datosArticulos = new ArrayList<>();

        cargarArticulos();
    }

    @Override
    public void onSelectedItem(Articulo articulo, int codigo, int stock) {

        switch (codigo) {
            case 1:
                cargaFragment(new FragmentDetallesArticulo(articulo), "detalles");
                break;
            case 2:
                cargaFragment(new FragmentStockArticulo(articulo, stock), "stock");
                break;
        }
    }


    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        if (item.getItemId() == 16908332)
            onBackPressed();

        return super.onOptionsItemSelected(item);
    }

    ///////////////////////FRAGMENTS///////////////////////
    public void cargaFragment(Fragment fragmentCargar, String tag) {
        FragmentManager FM = getSupportFragmentManager();
        FragmentTransaction FT = FM.beginTransaction();
        FT.replace(R.id.contenedorFragments, fragmentCargar, tag);
        FT.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
        FT.addToBackStack(tag);
        FT.commit();
    }
    ///////////////////////FRAGMENTS///////////////////////


    public void cargarArticulos() {
        ProveedorServicios proveedorServicios = MainActivity.crearRetrofit();

        Call<ArrayList<Articulo>> responseCall = proveedorServicios.getArticulos(1);

        //Llamada asíncrona gestionada por Retrofit y para ahorrar hilos
        responseCall.enqueue(new Callback<ArrayList<Articulo>>() {
            @Override
            public void onResponse(Call<ArrayList<Articulo>> call, Response<ArrayList<Articulo>> response) {
                ArrayList<Articulo> articulosResponse = response.body();

                if (articulosResponse != null) {
                    datosArticulos.addAll(articulosResponse);

                    cargaFragment(new FragmentArticulos(), "articulos");
                } else
                    Toast.makeText(getApplicationContext(), "Aún no hay artículos:" + response.message(), Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onFailure(Call<ArrayList<Articulo>> call, Throwable t) {
                Log.e("Error", t.toString());
                Toast.makeText(getApplicationContext(), "Error:" + t.toString(), Toast.LENGTH_SHORT).show();

            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_buscar, menu);
        MenuItem item = menu.findItem(R.id.opcBusqueda);
        SearchView searchView = (SearchView) item.getActionView();

        searchView.setOnQueryTextListener(this);

        return true;
    }

    @Override
    public void onBackPressed() {
        Fragment fragment = getSupportFragmentManager().findFragmentById(R.id.contenedorFragments);

        if (fragment != null) {
            if (fragment.getTag() != null) {
                //Si el fragment actual es el de la lista de artículos disponibles, la actividad finaliza.
                if (fragment.getTag().equalsIgnoreCase("articulos")) {
                    finish();
                    super.onBackPressed();
                } else super.onBackPressed();
            } else {
                super.onBackPressed();
            }
        } else {
            finish();
            super.onBackPressed();
        }
    }
    /////////////////Métodos de búsqueda y filtrado de artículos/////////////////
    @Override
    public boolean onQueryTextSubmit(String query) {
        onQueryTextSubmit(query);
        return false;
    }

    @Override
    public boolean onQueryTextChange(String newText) {

        try {
            if (!newText.equalsIgnoreCase("")) {
                datosArticulos = filter(datosArticulos, newText);
                cargaFragment(new FragmentArticulos(), "articulos");
            } else {
                datosArticulos.clear();
                cargarArticulos();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }

    private ArrayList<Articulo> filter(ArrayList<Articulo> articulos, String textoBuscar) {
        ArrayList<Articulo> listaFiltrada = new ArrayList<>();

        try {
            for (Articulo a : articulos) {
                if (a.getCodArticulo().toLowerCase().contains(textoBuscar.toLowerCase()) ||
                        a.getNombre().toLowerCase().contains(textoBuscar.toLowerCase())) {
                    listaFiltrada.add(a);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return listaFiltrada;
    }
    /////////////////Métodos de búsqueda de artículos/////////////////


    @Override
    public void onConfigurationChanged(@NonNull Configuration newConfig) {
        super.onConfigurationChanged(newConfig);

    }
}
