package com.jordi.psmanagement.clasespojo;

public class Categoria {
    int IdCategoria;
    String Categoria;

    public Categoria() {
    }

    public Categoria(int idCategoria, String categoria) {
        IdCategoria = idCategoria;
        Categoria = categoria;
    }

    public int getIdCategoria() {
        return IdCategoria;
    }

    public void setIdCategoria(int idCategoria) {
        IdCategoria = idCategoria;
    }

    public String getCategoria() {
        return Categoria;
    }

    public void setCategoria(String categoria) {
        Categoria = categoria;
    }

    @Override
    public String toString() {
        return "Categoria{" +
                "IdCategoria=" + IdCategoria +
                ", Categoria='" + Categoria + '\'' +
                '}';
    }
}
