package com.jordi.psmanagement.fragments;

import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.jordi.psmanagement.R;
import com.jordi.psmanagement.activities.MainActivity;
import com.jordi.psmanagement.clasespojo.Articulo;
import com.jordi.psmanagement.clasespojo.NumerosCalzado;
import com.jordi.psmanagement.clasespojo.TallasTextiles;
import com.jordi.psmanagement.interfaces.ProveedorServicios;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class FragmentStockArticulo extends Fragment {

    private Articulo articuloStock;
    private int tipoDeStock;
    private TextView nombreArticulo, codArticulo, xxs, xs, s, m, l, xl, xxl, n36, n37, n38, n39, n40, n41, n42, n43, n44, n45, n46, n47, total;
    private ArrayList<TextView> textViewsTallas, textViewNumeros;
    private int[] cantidadesTallas, cantidadesNumeros;

    public FragmentStockArticulo(Articulo articulo, int stock) {
        articuloStock = articulo;
        tipoDeStock = stock;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View rootView;
        if (tipoDeStock == 1) {

            rootView = inflater.inflate(R.layout.layout_tallas, container, false);

            nombreArticulo = rootView.findViewById(R.id.tvTallasNombreArt);
            codArticulo = rootView.findViewById(R.id.tvTallasModeloArt);

            nombreArticulo.setText(articuloStock.getNombre());
            codArticulo.setText(articuloStock.getCodArticulo());

            xxs = rootView.findViewById(R.id.tvTallaXXS);
            xs = rootView.findViewById(R.id.tvTallaXS);
            s = rootView.findViewById(R.id.tvTallaS);
            m = rootView.findViewById(R.id.tvTallaM);
            l = rootView.findViewById(R.id.tvTallaL);
            xl = rootView.findViewById(R.id.tvTallaXL);
            xxl = rootView.findViewById(R.id.tvTallaXXL);
            total = rootView.findViewById(R.id.tvTallaTotal);

            textViewsTallas = new ArrayList<>();
            textViewsTallas.add(xxs);
            textViewsTallas.add(xs);
            textViewsTallas.add(s);
            textViewsTallas.add(m);
            textViewsTallas.add(l);
            textViewsTallas.add(xl);
            textViewsTallas.add(xxl);
            textViewsTallas.add(total);

            cargaTallas(articuloStock.getCodArticulo());

        } else {
            rootView = inflater.inflate(R.layout.layout_numeros, container, false);

            nombreArticulo = rootView.findViewById(R.id.tvNumsNombreArt);
            codArticulo = rootView.findViewById(R.id.tvNumsModeloArt);

            nombreArticulo.setText(articuloStock.getNombre());
            codArticulo.setText(articuloStock.getCodArticulo());

            n36 = rootView.findViewById(R.id.tvN36);
            n37 = rootView.findViewById(R.id.tvN37);
            n38 = rootView.findViewById(R.id.tvN38);
            n39 = rootView.findViewById(R.id.tvN39);
            n40 = rootView.findViewById(R.id.tvN40);
            n41 = rootView.findViewById(R.id.tvN41);
            n42 = rootView.findViewById(R.id.tvN42);
            n43 = rootView.findViewById(R.id.tvN43);
            n44 = rootView.findViewById(R.id.tvN44);
            n45 = rootView.findViewById(R.id.tvN45);
            n46 = rootView.findViewById(R.id.tvN46);
            n47 = rootView.findViewById(R.id.tvN47);
            total = rootView.findViewById(R.id.tvNumTotal);

            textViewNumeros = new ArrayList<>();
            textViewNumeros.add(n36);
            textViewNumeros.add(n37);
            textViewNumeros.add(n38);
            textViewNumeros.add(n39);
            textViewNumeros.add(n40);
            textViewNumeros.add(n41);
            textViewNumeros.add(n42);
            textViewNumeros.add(n43);
            textViewNumeros.add(n44);
            textViewNumeros.add(n45);
            textViewNumeros.add(n46);
            textViewNumeros.add(n47);
            textViewNumeros.add(total);

            cargaNums(articuloStock.getCodArticulo());
        }

        return rootView;
    }

    private void cargaTallas(String codArticulo) {
        ProveedorServicios proveedorServicios = MainActivity.crearRetrofit();

        Call<ArrayList<TallasTextiles>> responseCall = proveedorServicios.getTallasTextiles(codArticulo);

        //Llamada asíncrona gestionada por Retrofit y para ahorrar hilos
        responseCall.enqueue(new Callback<ArrayList<TallasTextiles>>() {
            @Override
            public void onResponse(Call<ArrayList<TallasTextiles>> call, Response<ArrayList<TallasTextiles>> response) {
                ArrayList<TallasTextiles> articulosResponse = response.body();
                TallasTextiles tallas = articulosResponse != null ? articulosResponse.get(0) : null;
                if (tallas != null) {

                    cantidadesTallas = new int[]{tallas.getXXS(), tallas.getXS(), tallas.getS(), tallas.getM(), tallas.getL(), tallas.getXL(), tallas.getXXL(), tallas.getTotalCantidadArticulo()};

                    for (int i = 0; i < cantidadesTallas.length; i++) {
                        textViewsTallas.get(i).setText(String.valueOf(cantidadesTallas[i]));
                    }
                    compruebaStockMinimo(textViewsTallas, cantidadesTallas);
                } else
                    Toast.makeText(getActivity(), "Este artículo no tiene tallas textiles.\n" + response.message(), Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onFailure(Call<ArrayList<TallasTextiles>> call, Throwable t) {
                Log.e("Error", t.toString());
                Toast.makeText(getActivity(), "Error:" + t.toString(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void cargaNums(String codArticulo) {

        ProveedorServicios proveedorServicios = MainActivity.crearRetrofit();

        Call<ArrayList<NumerosCalzado>> responseCall = proveedorServicios.getNumerosCalzado(codArticulo);

        //Llamada asíncrona gestionada por Retrofit y para ahorrar hilos
        responseCall.enqueue(new Callback<ArrayList<NumerosCalzado>>() {
            @Override
            public void onResponse(Call<ArrayList<NumerosCalzado>> call, Response<ArrayList<NumerosCalzado>> response) {
                ArrayList<NumerosCalzado> articulosResponse = response.body();
                NumerosCalzado numeros = articulosResponse != null ? articulosResponse.get(0) : null;
                if (numeros != null) {

                    cantidadesNumeros = new int[]{numeros.getC36(), numeros.getC37(), numeros.getC38(), numeros.getC39(), numeros.getC40(), numeros.getC41(),
                            numeros.getC42(), numeros.getC43(), numeros.getC44(), numeros.getC45(), numeros.getC46(), numeros.getC47(), numeros.getTotalCantidadArticulo()};

                    for (int i = 0; i < cantidadesNumeros.length; i++) {
                        textViewNumeros.get(i).setText(String.valueOf(cantidadesNumeros[i]));
                    }

                    compruebaStockMinimo(textViewNumeros, cantidadesNumeros);

                } else
                    Toast.makeText(getActivity(), "Este artículo no tiene números de calzado:\n" + response.message(), Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onFailure(Call<ArrayList<NumerosCalzado>> call, Throwable t) {
                Log.e("Error", t.toString());
                Toast.makeText(getActivity(), "Error:" + t.toString(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void compruebaStockMinimo(ArrayList<TextView> textViews, int[] tallasONums) {
        for (int i = 0; i < tallasONums.length; i++) {
            if (tallasONums[i] <= articuloStock.getStockMinimo())
                textViews.get(i).setBackgroundColor(Color.RED);
        }
    }

}
