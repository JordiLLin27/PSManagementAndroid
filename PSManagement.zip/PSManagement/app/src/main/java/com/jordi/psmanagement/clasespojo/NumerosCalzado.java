package com.jordi.psmanagement.clasespojo;

public class NumerosCalzado {

    String CodArticulo;
    int C36, C37, C38, C39, C40, C41, C42, C43, C44, C45, C46, C47, TotalCantidadArticulo;

    public NumerosCalzado() {
    }

    public NumerosCalzado(String codArticulo, int c36, int c37, int c38, int c39, int c40, int c41, int c42, int c43, int c44, int c45, int c46, int c47, int totalCantidadArticulo) {
        CodArticulo = codArticulo;
        C36 = c36;
        C37 = c37;
        C38 = c38;
        C39 = c39;
        C40 = c40;
        C41 = c41;
        C42 = c42;
        C43 = c43;
        C44 = c44;
        C45 = c45;
        C46 = c46;
        C47 = c47;
        TotalCantidadArticulo = totalCantidadArticulo;
    }

    public String getCodArticulo() {
        return CodArticulo;
    }

    public void setCodArticulo(String codArticulo) {
        CodArticulo = codArticulo;
    }

    public int getC36() {
        return C36;
    }

    public void setC36(int c36) {
        C36 = c36;
    }

    public int getC37() {
        return C37;
    }

    public void setC37(int c37) {
        C37 = c37;
    }

    public int getC38() {
        return C38;
    }

    public void setC38(int c38) {
        C38 = c38;
    }

    public int getC39() {
        return C39;
    }

    public void setC39(int c39) {
        C39 = c39;
    }

    public int getC40() {
        return C40;
    }

    public void setC40(int c40) {
        C40 = c40;
    }

    public int getC41() {
        return C41;
    }

    public void setC41(int c41) {
        C41 = c41;
    }

    public int getC42() {
        return C42;
    }

    public void setC42(int c42) {
        C42 = c42;
    }

    public int getC43() {
        return C43;
    }

    public void setC43(int c43) {
        C43 = c43;
    }

    public int getC44() {
        return C44;
    }

    public void setC44(int c44) {
        C44 = c44;
    }

    public int getC45() {
        return C45;
    }

    public void setC45(int c45) {
        C45 = c45;
    }

    public int getC46() {
        return C46;
    }

    public void setC46(int c46) {
        C46 = c46;
    }

    public int getC47() {
        return C47;
    }

    public void setC47(int c47) {
        C47 = c47;
    }

    public int getTotalCantidadArticulo() {
        return TotalCantidadArticulo;
    }

    public void setTotalCantidadArticulo(int totalCantidadArticulo) {
        TotalCantidadArticulo = totalCantidadArticulo;
    }

    @Override
    public String toString() {
        return "NumerosCalzado{" +
                "CodArticulo='" + CodArticulo + '\'' +
                ", C36=" + C36 +
                ", C37=" + C37 +
                ", C38=" + C38 +
                ", C39=" + C39 +
                ", C40=" + C40 +
                ", C41=" + C41 +
                ", C42=" + C42 +
                ", C43=" + C43 +
                ", C44=" + C44 +
                ", C45=" + C45 +
                ", C46=" + C46 +
                ", C47=" + C47 +
                ", TotalCantidadArticulo=" + TotalCantidadArticulo +
                '}';
    }
}
