package com.jordi.psmanagement.fragments;

import android.content.Context;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.jordi.psmanagement.R;

import com.jordi.psmanagement.activities.MainActivity;
import com.jordi.psmanagement.clasespojo.Articulo;
import com.jordi.psmanagement.clasespojo.Categoria;
import com.jordi.psmanagement.clasespojo.Color;
import com.jordi.psmanagement.clasespojo.Inventario;
import com.jordi.psmanagement.clasespojo.NumerosCalzado;
import com.jordi.psmanagement.clasespojo.TallasTextiles;
import com.jordi.psmanagement.interfaces.OnSelectedItemListener;
import com.jordi.psmanagement.interfaces.ProveedorServicios;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class FragmentDetallesArticulo extends Fragment {
    private Articulo articulo;
    private Color colorArticulo;
    private Inventario inventarioArticulo;
    private Categoria categoriaArticulo;
    private OnSelectedItemListener listener;

    public FragmentDetallesArticulo(Articulo articulo) {
        this.articulo = articulo;
        this.colorArticulo = new Color();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.layout_articulo, container, false);

        TextView nombre, modelo, inventario, color, categoria;
        ImageView imageViewDetallesArticulo;

        nombre = rootView.findViewById(R.id.textviewNombreArticulo);
        modelo = rootView.findViewById(R.id.textviewCodigoArticulo);
        inventario = rootView.findViewById(R.id.textviewInventario);
        color = rootView.findViewById(R.id.textviewColor);
        categoria = rootView.findViewById(R.id.textviewCategoria);

        imageViewDetallesArticulo = rootView.findViewById(R.id.ivDetallesArticuloImagen);

        nombre.setText(articulo.getNombre());
        modelo.setText(articulo.getCodArticulo());

        cargarColores(color);
        cargaInventario(inventario);
        cargaCategoria(categoria);

        if (!articulo.getUrlImagen().contains("Assets")) {
            Picasso.get().load(articulo.getUrlImagen()).into(imageViewDetallesArticulo);
        } else {
            imageViewDetallesArticulo.setImageResource(R.drawable.no_image_available);
        }

        Button botonTallasNums = rootView.findViewById(R.id.botonCompruebaStock);

        botonTallasNums.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cargaTallas(articulo.getCodArticulo());
            }
        });

        return rootView;
    }

    private void cargaCategoria(TextView categoria) {
        ProveedorServicios proveedorServicios = MainActivity.crearRetrofit();

        Call<ArrayList<Categoria>> responseCall = proveedorServicios.getCategoria(articulo.getCategoria());
        responseCall.enqueue(new Callback<ArrayList<Categoria>>() {
            @Override
            public void onResponse(Call<ArrayList<Categoria>> call, Response<ArrayList<Categoria>> response) {
                ArrayList<Categoria> respuesta = response.body();

                if (respuesta != null) {
                    categoriaArticulo = respuesta.get(0);
                    categoria.setText(categoriaArticulo.getCategoria());
                } else
                    Toast.makeText(getActivity(), "No existe la categoría", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onFailure(Call<ArrayList<Categoria>> call, Throwable t) {
                Toast.makeText(getActivity(), "No existe la categoría", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void cargaInventario(TextView inventario) {
        ProveedorServicios proveedorServicios = MainActivity.crearRetrofit();

        Call<ArrayList<Inventario>> responseCall = proveedorServicios.getInventario(articulo.getInventario());
        responseCall.enqueue(new Callback<ArrayList<Inventario>>() {
            @Override
            public void onResponse(Call<ArrayList<Inventario>> call, Response<ArrayList<Inventario>> response) {
                ArrayList<Inventario> respuesta = response.body();

                if (respuesta != null) {
                    inventarioArticulo = respuesta.get(0);
                    inventario.setText(inventarioArticulo.getDescripcion());
                } else
                    Toast.makeText(getActivity(), "No existe el inventario", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onFailure(Call<ArrayList<Inventario>> call, Throwable t) {
                Toast.makeText(getActivity(), "No existe el inventario", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void cargarColores(TextView tvColor) {
        ProveedorServicios proveedorServicios = MainActivity.crearRetrofit();

        Call<ArrayList<Color>> responseCall = proveedorServicios.getColor(articulo.getColor());
        responseCall.enqueue(new Callback<ArrayList<Color>>() {
            @Override
            public void onResponse(Call<ArrayList<Color>> call, Response<ArrayList<Color>> response) {
                ArrayList<Color> respuesta = response.body();

                if (respuesta != null) {
                    colorArticulo = respuesta.get(0);
                    tvColor.setText(colorArticulo.getColor());
                } else
                    Toast.makeText(getActivity(), "No existe el color", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onFailure(Call<ArrayList<Color>> call, Throwable t) {
                Toast.makeText(getActivity(), "No existe el color", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void cargaTallas(String codArticulo) {
        ProveedorServicios proveedorServicios = MainActivity.crearRetrofit();

        Call<ArrayList<TallasTextiles>> responseCall = proveedorServicios.getTallasTextiles(codArticulo);

        //Llamada asíncrona gestionada por Retrofit y para ahorrar hilos
        responseCall.enqueue(new Callback<ArrayList<TallasTextiles>>() {
            @Override
            public void onResponse(Call<ArrayList<TallasTextiles>> call, Response<ArrayList<TallasTextiles>> response) {
                ArrayList<TallasTextiles> articulosResponse = response.body();
                TallasTextiles tallas = articulosResponse != null ? articulosResponse.get(0) : null;
                if (tallas != null) {
                    listener.onSelectedItem(articulo, 2, 1);
                } else {
                    cargaNums(articulo.getCodArticulo());
                }
            }

            @Override
            public void onFailure(Call<ArrayList<TallasTextiles>> call, Throwable t) {
                Log.e("Error", t.toString());
                Toast.makeText(getActivity(), "Error:" + t.toString(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void cargaNums(String codArticulo) {

        ProveedorServicios proveedorServicios = MainActivity.crearRetrofit();

        Call<ArrayList<NumerosCalzado>> responseCall = proveedorServicios.getNumerosCalzado(codArticulo);

        //Llamada asíncrona gestionada por Retrofit y para ahorrar hilos
        responseCall.enqueue(new Callback<ArrayList<NumerosCalzado>>() {
            @Override
            public void onResponse(Call<ArrayList<NumerosCalzado>> call, Response<ArrayList<NumerosCalzado>> response) {
                ArrayList<NumerosCalzado> articulosResponse = response.body();
                NumerosCalzado numeros = articulosResponse != null ? articulosResponse.get(0) : null;
                if (numeros != null) {
                    listener.onSelectedItem(articulo, 2, 2);

                } else
                    Toast.makeText(getActivity(), "Aún no hay artículos:" + response.message(), Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onFailure(Call<ArrayList<NumerosCalzado>> call, Throwable t) {
                Log.e("Error", t.toString());
                Toast.makeText(getActivity(), "Error:" + t.toString(), Toast.LENGTH_SHORT).show();
            }
        });

    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        try {
            listener = (OnSelectedItemListener) context;
        } catch (ClassCastException e) {
            e.printStackTrace();
        }
    }
}
