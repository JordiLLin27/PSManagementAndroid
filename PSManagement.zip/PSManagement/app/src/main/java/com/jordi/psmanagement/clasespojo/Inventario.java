package com.jordi.psmanagement.clasespojo;

public class Inventario {
    int IdInventario;
    String Descripcion;
    String FechaCreacion;

    public Inventario() {
    }

    public Inventario(int idInventario, String descripcion, String fechaCreacion) {
        IdInventario = idInventario;
        Descripcion = descripcion;
        FechaCreacion = fechaCreacion;
    }

    public int getIdInventario() {
        return IdInventario;
    }

    public void setIdInventario(int idInventario) {
        IdInventario = idInventario;
    }

    public String getDescripcion() {
        return Descripcion;
    }

    public void setDescripcion(String descripcion) {
        Descripcion = descripcion;
    }

    public String getFechaCreacion() {
        return FechaCreacion;
    }

    public void setFechaCreacion(String fechaCreacion) {
        FechaCreacion = fechaCreacion;
    }

    @Override
    public String toString() {
        return "Inventario{" +
                "IdInventario=" + IdInventario +
                ", Descripcion='" + Descripcion + '\'' +
                ", FechaCreacion=" + FechaCreacion +
                '}';
    }
}
